/* Seite "Trainingszeiten": je Mannschaft eine Karte mit Orten,
 * Trainingszeiten fuer Sommer und Winter, den naechsten drei Spielen
 * und den Ansprechpartnern.
 *
 * Die Zeiten stammen aus config/mannschaften.json und werden von Hand
 * gepflegt - FUSSBALL.DE kennt sie nicht. Die Spiele kommen von
 * FUSSBALL.DE (data/matches.json) und klappen wie in der Spielübersicht
 * auf. Fehlt etwas, sagt die Seite das offen, statt eine Luecke zu
 * kaschieren.
 */

(function () {
  "use strict";

  var WOCHENTAGE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag",
    "Freitag", "Samstag", "Sonntag"];
  var ANZAHL_SPIELE = 3;

  var S = window.Seite;
  var text = S.text;
  var offen = {};

  /* Eine Mannschaft kann Zeiten je Jahreszeit haben. Aeltere Eintraege
   * (eine einfache Liste) gelten als Sommerzeiten. */
  function einheitenFuer(eintrag, saison) {
    var t = eintrag && eintrag.training;

    if (Array.isArray(t)) {
      return saison === "sommer" ? t : [];
    }
    return (t && t[saison]) || [];
  }

  function datumDe(iso) {
    var t = String(iso || "").split("-");
    return t.length === 3 ? t[2] + "." + t[1] + "." + t[0] : "";
  }

  /* --- Orte --------------------------------------------------------- */

  function ortKurz(ort) {
    return ort.abk || ort.name;
  }

  /* Ort mit Abkuerzung; Anschrift und Karte dezent dahinter. */
  function ortZeile(titel, ort) {
    var anschrift = S.adresse(ort);
    var karte = S.kartenLink(ort);
    var weg = [];

    if (anschrift) {
      weg.push(text(anschrift));
    }
    if (karte) {
      weg.push('<a href="' + text(karte)
        + '" target="_blank" rel="noopener">Karte</a>');
    }

    return "<li><b>" + titel + ":</b> " + text(ortKurz(ort))
      + (ort.abk && ort.name !== ort.abk
        ? ' <span class="leise">' + text(ort.name) + "</span>" : "")
      + (weg.length ? '<span class="kontaktweg">' + weg.join(" · ")
        + "</span>" : "")
      + "</li>";
  }

  /* Haupt- und Nebenort der Mannschaft. */
  function orteHtml(eintrag) {
    var orte = S.orte();
    var zeilen = [];

    [["Hauptort", eintrag.hauptort], ["Nebenort", eintrag.nebenort]]
      .forEach(function (paar) {
        if (orte[paar[1]]) {
          zeilen.push(ortZeile(paar[0], orte[paar[1]]));
        }
      });

    return zeilen.length
      ? '<ul class="kontakte orte">' + zeilen.join("") + "</ul>" : "";
  }

  /* --- Trainingszeiten ---------------------------------------------- */

  function sortiereEinheiten(einheiten) {
    return einheiten.slice().sort(function (a, b) {
      var tagA = WOCHENTAGE.indexOf(a.tag);
      var tagB = WOCHENTAGE.indexOf(b.tag);

      if (tagA !== tagB) {
        return tagA - tagB;
      }
      return (a.von || "") < (b.von || "") ? -1 : 1;
    });
  }

  function zeileTraining(e, eintrag) {
    var zeit = e.von && e.bis ? e.von + " – " + e.bis + " Uhr"
      : (e.von ? "ab " + e.von + " Uhr" : "");
    var r = S.aufloesen(e, eintrag);
    var abk = "";
    var wo = "";

    if (r.fehler) {
      wo = "? " + r.fehler;
    } else {
      abk = ortKurz(r.ort);

      // Eigener Platz: Rasenart und Teil des Platzes
      if (r.kuerzel) {
        wo = r.ort.name + (r.feld && r.feld !== "G"
          ? ", " + S.felder[r.feld].name : "");
      }
    }

    return "<tr><th>" + text(e.tag || "")
      + (abk ? ' <span class="abk">(' + text(abk) + ")</span>" : "")
      + "</th><td>" + text(zeit) + '</td><td class="leise">' + text(wo)
      + (e.hinweis ? (wo ? " · " : "") + text(e.hinweis) : "")
      + "</td></tr>";
  }

  function saisonHtml(saison, eintrag, aktuell) {
    var def = S.saisonListe()[saison] || {};
    var einheiten = einheitenFuer(eintrag, saison);
    var kopf = '<h4 class="saison-kopf">' + text(def.name || saison)
      + (saison === aktuell ? ' <span class="marke-aktuell">aktuell</span>'
        : "")
      + (S.istBeispiel(saison)
        ? ' <span class="marke-beispiel">Beispiel</span>' : "")
      + (def.ab ? ' <span class="leise">ab ' + datumDe(def.ab) + "</span>"
        : "")
      + "</h4>";

    if (!einheiten.length) {
      return kopf + '<p class="leise">Noch nicht hinterlegt.</p>';
    }

    return kopf + '<table class="training">' + sortiereEinheiten(einheiten)
      .map(function (e) { return zeileTraining(e, eintrag); }).join("")
      + "</table>";
  }

  /* --- Naechste Spiele ---------------------------------------------- */

  function naechsteSpiele(slug) {
    var heute = S.heute();

    return ((S.daten().spiele && S.daten().spiele.matches) || [])
      .filter(function (spiel) {
        return spiel.teamSlug === slug && new Date(spiel.start) >= heute;
      })
      .sort(function (a, b) {
        return new Date(a.start) - new Date(b.start);
      })
      .slice(0, ANZAHL_SPIELE);
  }

  function kurzesDatum(iso) {
    return new Date(iso + "T12:00:00").toLocaleDateString("de-DE", {
      weekday: "short", day: "2-digit", month: "2-digit"
    });
  }

  function spieleZeilen(slug) {
    return naechsteSpiele(slug).map(function (spiel) {
      return Spielzeile.zeile(spiel, offen[spiel.id], {
        datum: kurzesDatum(spiel.date)
      });
    }).join("");
  }

  function spieleHtml(slug) {
    var zeilen = spieleZeilen(slug);

    return "<h4>Nächste Spiele</h4>" + (zeilen
      ? '<table class="spieltage kompakt" data-team="' + text(slug)
        + '"><tbody>' + zeilen + "</tbody></table>"
      : '<p class="leise">Derzeit kein Spiel angesetzt.</p>');
  }

  /* --- Ansprechpartner ---------------------------------------------- */

  function kontaktHtml(kontakte) {
    var gepflegt = (kontakte || []).filter(function (k) {
      return k.name || k.email || k.telefon;
    });

    if (!gepflegt.length) {
      return '<p class="leise">Ansprechpartner noch nicht hinterlegt.</p>';
    }

    var zeilen = gepflegt.map(function (k) {
      var wege = [];

      if (k.email) {
        wege.push('<a href="mailto:' + text(k.email) + '">'
          + text(k.email) + "</a>");
      }
      if (k.telefon) {
        wege.push(text(k.telefon));
      }

      return "<li><b>" + text(k.name || k.rolle || "") + "</b>"
        + (k.rolle && k.name ? ' <span class="leise">' + text(k.rolle)
          + "</span>" : "")
        + (wege.length ? '<span class="kontaktweg">' + wege.join(" · ")
          + "</span>" : "")
        + "</li>";
    });

    return '<ul class="kontakte">' + zeilen.join("") + "</ul>";
  }

  /* --- Karte -------------------------------------------------------- */

  function karte(team, eintrag, aktuell) {
    eintrag = eintrag || {};

    var voll = S.ohneVerein(team.name);
    var jsg = /JSG/.test(team.name);
    var reihenfolge = aktuell === "winter" ? ["winter", "sommer"]
      : ["sommer", "winter"];

    return '<article class="mannschaft" id="' + text(team.slug) + '">'
      + "<h3>" + text(team.short)
      + (jsg ? ' <span class="marke-jsg" title="Spielgemeinschaft">JSG</span>'
        : "") + "</h3>"
      + (voll && voll !== team.short
        ? '<p class="leise voller-name">' + text(voll) + "</p>" : "")
      + orteHtml(eintrag)
      + reihenfolge.map(function (saison) {
        return saisonHtml(saison, eintrag, aktuell);
      }).join("")
      + (eintrag.hinweis
        ? '<p class="trainingshinweis">' + text(eintrag.hinweis) + "</p>"
        : "")
      + spieleHtml(team.slug)
      + "<h4>Ansprechpartner</h4>"
      + kontaktHtml(eintrag.kontakt)
      + '<p class="mannschaft-links">'
      + '<a class="zeilen-knopf" href="index.html?team='
      + text(team.slug) + '">Alle Spiele</a>'
      + '<a class="zeilen-knopf" href="kalender/' + text(team.slug)
      + '.ics">Kalender</a>'
      + "</p></article>";
  }

  S.start({
    seite: "training",
    braucht: ["teams", "spiele", "mannschaften"],
    fertig: function (daten) {
      var ziel = document.getElementById("trainingbereich");
      var pflege = (daten.mannschaften && daten.mannschaften.mannschaften)
        || {};
      var aktuell = S.aktuelleSaison();
      var html = [];

      if (!daten.mannschaften) {
        html.push('<p class="warnung">Die Datei '
          + "<code>config/mannschaften.json</code> fehlt. Ohne sie kann "
          + "diese Seite nichts anzeigen.</p>");
      }

      S.bereiche().forEach(function (bereich) {
        html.push("<h2>" + text(bereich.titel) + "</h2>");

        if (bereich.hinweis) {
          html.push('<p class="leise bereich-hinweis">'
            + text(bereich.hinweis) + "</p>");
        }

        html.push('<div class="mannschaft-raster">');
        bereich.teams.forEach(function (team) {
          html.push(karte(team, pflege[team.slug], aktuell));
        });
        html.push("</div>");
      });

      ziel.innerHTML = html.join("");

      // Spiele klappen wie in der Spielübersicht auf.
      ziel.addEventListener("click", function (ereignis) {
        var knopf = ereignis.target.closest(".partie");

        if (!knopf) {
          return;
        }

        var tabelle = knopf.closest("table[data-team]");
        var id = knopf.dataset.auf;

        if (offen[id]) {
          delete offen[id];
        } else {
          offen[id] = true;
        }

        tabelle.querySelector("tbody").innerHTML =
          spieleZeilen(tabelle.dataset.team);
      });
    }
  });
}());
