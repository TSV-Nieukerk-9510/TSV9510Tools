/* Seite "Sportanlage": Luftbild, Anschrift, Plaetze und Ausstattung.
 *
 * Alle Texte stammen aus config/sportanlage.json, die Anschrift aus den
 * Orten in config/mannschaften.json. Die Seite erfindet nichts: leere
 * Abschnitte werden ausgeblendet, ein fehlendes Foto durch einen
 * Platzhalter ersetzt.
 */

(function () {
  "use strict";

  var S = window.Seite;
  var text = S.text;

  function fotoHtml(foto) {
    if (!foto || !foto.datei) {
      return "";
    }

    return '<figure class="anlage-foto">'
      + '<img src="' + text(foto.datei) + '" alt="' + text(foto.alt || "")
      + '" loading="lazy">'
      + '<div class="anlage-platzhalter" hidden>Luftaufnahme folgt. '
      + "Die Datei <code>" + text(foto.datei) + "</code> ablegen, dann "
      + "erscheint sie hier.</div>"
      + (foto.quelle ? "<figcaption>" + text(foto.quelle) + "</figcaption>"
        : "")
      + "</figure>";
  }

  function adresseHtml(ort) {
    var karte = S.kartenLink(ort);

    return '<section class="anlage-adresse"><h2>Adresse</h2>'
      + '<p class="anschrift"><b>TSV Nieukerk 95/10</b><br>'
      + text(ort.strasse || "") + "<br>" + text(ort.plz || "") + " "
      + text(ort.ort || "") + "</p>"
      + (karte ? '<p><a class="zeilen-knopf" href="' + text(karte)
        + '" target="_blank" rel="noopener">Auf der Karte öffnen</a></p>'
        : "") + "</section>";
  }

  function platzKarten(plaetze, orte) {
    var karten = (plaetze || []).map(function (p) {
      var ort = orte[p.ort] || {};

      return '<article class="mannschaft"><h3>' + text(p.titel || ort.name
        || "") + "</h3>" + (p.text ? "<p>" + text(p.text) + "</p>" : "")
        + "</article>";
    });

    return karten.length
      ? "<h2>Plätze</h2>" + '<div class="mannschaft-raster">'
        + karten.join("") + "</div>"
      : "";
  }

  function liste(titel, eintraege) {
    if (!eintraege || !eintraege.length) {
      return "";
    }

    return "<h2>" + text(titel) + "</h2>" + '<ul class="anlage-liste">'
      + eintraege.map(function (e) {
        return "<li><b>" + text(e.titel || "") + "</b>"
          + (e.text ? "<span>" + text(e.text) + "</span>" : "") + "</li>";
      }).join("") + "</ul>";
  }

  S.start({
    seite: "sportanlage",
    braucht: ["teams", "mannschaften", "sportanlage"],
    fertig: function (daten) {
      var ziel = document.getElementById("anlagebereich");
      var c = daten.sportanlage || {};
      var orte = S.orte();
      var haupt = orte["nieukerk-kunstrasen"]
        || orte[Object.keys(orte)[0]] || {};
      var html = [];

      if (c.einleitung) {
        html.push('<p class="einleitung">' + text(c.einleitung) + "</p>");
      }
      html.push(fotoHtml(c.foto));
      html.push(adresseHtml(haupt));
      html.push(platzKarten(c.plaetze, orte));
      html.push(liste("Ausstattung", c.ausstattung));
      html.push(liste("Gut zu wissen", c.hinweise));
      html.push('<p class="leise">Wer wann auf welchem Platz trainiert, '
        + 'zeigt die <a href="platzbelegung.html">Platzbelegung</a>.</p>');

      ziel.innerHTML = html.join("");

      // Fehlt das Foto, erscheint der Platzhalter statt eines leeren Rahmens.
      var bild = ziel.querySelector(".anlage-foto img");

      if (bild) {
        var fehlt = function () {
          bild.hidden = true;
          ziel.querySelector(".anlage-platzhalter").hidden = false;
        };

        bild.addEventListener("error", fehlt);
        if (bild.complete && bild.naturalWidth === 0) {
          fehlt();
        }
      }
    }
  });
}());
